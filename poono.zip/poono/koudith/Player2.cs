﻿using UnityEngine;
using System.Collections;

public class player2 : MonoBehaviour {

	public float playerVelocity;
	private Vector3 playerPosition;
	public float boundary;

	private int playerLives;
	private int playerPoints;

	// Use this for initialization
	void Start () {
		// get the initial position of the game object
		playerPosition = gameObject.transform.position;

		playerLives = 3;
		playerPoints = 0;

		//onGUI ();
	}

	// Update is called once per frame
	void Update () {
		// horizontal movement
		playerPosition.x += Input.GetAxis("Vertical") * playerVelocity;

		// leave the game
		if (Input.GetKeyDown(KeyCode.Escape)){
			Application.Quit();
		}

		// update the game object transform
		transform.position = playerPosition;

		// boundaries
		if (playerPosition.x < -boundary) {
			transform.position = new Vector3 (-boundary, playerPosition.y, playerPosition.z);		
		} 
		if (playerPosition.x > boundary) {
			transform.position = new Vector3(boundary, playerPosition.y, playerPosition.z);		
		}



	}

	void addPoints(int points){
		playerPoints += points;
	}

	void OnGUI(){




		//"Live's: " + playerLives +
//		GUI.Label (new Rect(425.0f,30.0f,200.0f,200.0f), "  Score: " + playerPoints);
//		if ( GUI.Button(new Rect(130, 83, 100, 50),"Add", GUI.skin.button) ) {
//			playerPoints = playerPoints + 50;
//
//
//		}
		if (Application.loadedLevelName.Equals ("levu")) {
//			if (GUI.Button (new Rect (50, 40, 100, 50), "Next Level")) {
//
//				if (Application.loadedLevelName.Equals ("levu")) {
//					Application.LoadLevel ("Level1"); //Awake ();//Debug.Log("Clicked the button with an image");
//				}
//			}
		}

	}

	void TakeLife(){
		playerLives--;
	}
}
