﻿using UnityEngine;
using System.Collections;

public class folowdasomeoneforamoment : MonoBehaviour {

		private Transform target;
		private float speed = 2f;
		private Vector3 speedRot = Vector3.right * 50f;
		public float delta = 5.5f;  // Amount to move left and right from the start point

		private Vector3 startPos;
		void Start () {
			target = GameObject.FindGameObjectWithTag("Player").transform;

			
		}

		void Update () {
		if (GameObject.Find ("Player") != null) {
			transform.Rotate (speedRot * Time.deltaTime);
			transform.position = Vector3.MoveTowards (transform.position, target.position, speed * Time.deltaTime);
		}
			
			
			
		}




	}

