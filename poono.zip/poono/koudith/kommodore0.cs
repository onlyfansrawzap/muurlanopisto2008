﻿using UnityEngine;
using System.Collections;



public class kommodore0 : MonoBehaviour {
	public GameObject instance;
	void Start(){
	GameObject myNewInstance = (GameObject) Instantiate(instance, transform.position, transform.rotation);
	myNewInstance.transform.localPosition = new Vector3(0.0f, 0.0f, 5.0f);
	}

}
