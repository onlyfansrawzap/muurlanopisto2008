﻿using UnityEngine;
using System.Collections;

public class masdfsdafdasf : MonoBehaviour {

		public float playerVelocity;
		private Vector3 playerPosition;
		public float boundary;
		
		private int playerLives;
		private int playerPoints;

		// Use this for initialization
		void Start () {
			// get the initial position of the game object
			playerPosition = gameObject.transform.position;

			playerLives = 3;
			playerPoints = 0;

			//onGUI ();
		}

		// Update is called once per frame
		void Update () {
			// horizontal movement
			playerPosition.x += Input.GetAxis("Horizontal3") * playerVelocity;

			// leave the game
			if (Input.GetKeyDown(KeyCode.Escape)){
				Application.Quit();
			}

			// update the game object transform
			transform.position = playerPosition;

			// boundaries
			if (playerPosition.x < -boundary) {
				transform.position = new Vector3 (-boundary, playerPosition.y, playerPosition.z);		
			} 
			if (playerPosition.x > boundary) {
				transform.position = new Vector3(boundary, playerPosition.y, playerPosition.z);		
			}



		}

		void addPoints(int points){
			playerPoints += points;
		}

		void OnGUI(){//"Live's: " + playerLives +


			

		}

	void OnCollisionEnter2D(Collision2D collision){

		if (collision.gameObject.tag == "Ball") {


			//
			//Debug.Log ("lisääsli0923493242");
			//GameObject go4;
			//prefabEffect.transform.SetParent (fpcontoler);
			//string m0;
			//m0 = gameObject.transform.GetChild (0).name;
			//hand = GameObject.Find("Player/Explosionx/Flame");
			//hand.SetActive (true);


			//GameObject go3 = Instantiate(hand) as GameObject;
			//go3.transform.parent = gameObject.transform;
			//fpcontoler = go3.transform;
			//go3.transform.SetParent (fpcontoler);
			//go3.transform.parent = transform;
			//prefabEffect.transform.parent = transform;
			//go3.transform.parent = fpcontoler;
			//GameObject ps = particleSystem.name;
			//GameObject go = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
			//Destroy (go, 10);
			//GameObject go2 = Instantiate (particleSystems, Vector3.zero, Quaternion.identity) as GameObject;
			//Destroy (go2, 10);
			//Destroy(GameObject.Find("Ball"), 1);
			//Destroy(GameObject.Find("Ball (1)"), 1);
			//Destroy(this.gameObject, 1);
		}
	}
		void TakeLife(){
			playerLives--;
		}
	

}
